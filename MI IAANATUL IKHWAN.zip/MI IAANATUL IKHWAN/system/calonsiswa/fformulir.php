
<?php	//	LOAD DATA CALON SISWA

	$kode=$_SESSION["KODELOG"];
	$sql="select * from  tbl_calonsiswa where f_nopendaftaran='$kode' ";
	$hasil=mysql_query($sql);
	$data=mysql_fetch_array($hasil);
		$namalengkap=$data["f_namalengkap"];
		$alamat = $data["f_alamatsiswa"];
		$namaayah = $data["f_namaayah"];		
		$namaibu = $data["f_namaibu"];
		$lulusansekolah=$data["f_lulusansekolah"];
		$nosttb = $data["f_nosttb"];
		$aktekel = $data["f_aktekel"];
		$sktb = $data["f_sktb"];
		$foto = $data["f_foto"];
?>
<style type="text/css">
<!--
.style1{
	color:#FF0000;
}		
.style2 {
	font-size: 16px;
	color: #00FF00;
}
-->
</style>


<div id="comments">
	<h2>Cetak Bukti Pendaftaran Siswa Baru Online</h2>
	<ul class="commentlist">
		<li class="comment_odd">Anda diwajibkan untuk mencetak bukti pendaftaran online sebagai salah satu syarat yang harus dibawa saat mendaftar ulang</li>
		<li class="comment_even">
			<div class='author'><img class='avatar' src='images/peringatan.png' alt='' width='32' height='32' /></div>
 <?php 

			  if($namalengkap==NULL || $alamat==NULL){ 
				  echo "<em  class='style1'><b>!</b> Maaf, Anda Belum Melengkapi Biodata Calon Siswa... </em><br>";
			  }
			  if($namaayah==NULL || $namaibu==NULL){ 
				  echo "<em  class='style1'><b>!</b> Maaf, Anda Belum Melengkapi Data Orang Tua... </em><br>";
				   }
			  if($nosttb==NULL || $lulusansekolah==NULL){ 
				  echo "<em  class='style1'><b>!</b> Maaf, Anda Belum Melengkapi Data Sekolah Asal... </em><br>";
			  }
			  
			  if($aktekel==NULL || $sktb==NULL || $foto==NULL){
				 echo "<em  class='style1'><b>!</b> Maaf, Anda Belum Upload Lampiran... </em><br>";
			  }
			  
			  else{
			  	echo"<h1><a href='./fotocalonsiswa/_formulir1.php?kode=$_SESSION[ULOGIN]'>Silahkan Cetak Formulir...</a></h1>";
							
			  }
		?>
		</li>
	</ul>
</div>
