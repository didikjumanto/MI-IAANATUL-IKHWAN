
<style type="text/css">
<!--
.stylebelumupload {color:#FF0000}
.stylesudahdisetujui {color:#33CC00}
-->
</style>

<h2>UPLOAD LAMPIRAN CALON SISWA</h2>

  <table width="494">
     <tr>
      <td width="486" height="56" colspan="2" align="center" valign="top">
		  <?php 
		
				 echo "<em><b>!</b> Maaf, Anda Belum Upload Akte Kelahiran... <a href='?mnu=fuploadakte'>Silahkan klik disini untuk Upload Akte Kelahiran...</a></em><br><br>";
				  echo "<em><b>!</b> Maaf, Anda Belum Upload SKTB... <a href='?mnu=fuploadsktb'>Silahkan klik disini untuk Upload SKTB...</a></em><br><br>"; 
				  echo "<em><b>!</b> Maaf, Anda Belum Upload Pas Foto... <a href='?mnu=fuploadfoto'>Silahkan klik disini untuk Upload Foto...</a></em><br><br>";
			
		  ?>
	 
	  </td>
    </tr>
</table>
  
