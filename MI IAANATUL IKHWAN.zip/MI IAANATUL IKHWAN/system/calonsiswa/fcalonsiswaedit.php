<?php
$PATHJAVASCRIPT="scripts";
?>

<link type="text/css" href="<?php echo "$PATHJAVASCRIPT/base/";?>ui.all.css" rel="stylesheet" />   
<script type="text/javascript" src="<?php echo "$PATHJAVASCRIPT/";?>jquery-1.3.2.js"></script>
<script type="text/javascript" src="<?php echo "$PATHJAVASCRIPT/";?>ui/ui.core.js"></script>
<script type="text/javascript" src="<?php echo "$PATHJAVASCRIPT/";?>ui/ui.datepicker.js"></script>
<script type="text/javascript" src="<?php echo "$PATHJAVASCRIPT/";?>ui/i18n/ui.datepicker-id.js"></script>    
  <script type="text/javascript"> 
      $(document).ready(function(){
        $("#tanggallhrsiswa").datepicker({
					dateFormat  : "dd/MM/yy",        
          changeMonth : true,
          changeYear  : true					
        });
      });
    </script>  
	
<style type="text/css">
<!--
.style3 {font-size: 12px}
-->
</style>

<style type="text/css">
<!--
.style4 {
	color: #FF0000;
	font-weight: bold;
}
-->
</style>

<div id='comments'>
<h2>Biodata Calon Siswa Baru</h2>
	<ul class='commentlist'>
		<li class='comment_odd'>
			&diams; Lengkapilah Data dibawah ini sesuai dengan data asli <br />
			&diams; Perhatikan seluruh inputan yang anda masukan disini <br />
<!--			&diams; Sistem tidak bisa menyimpan apabila ada masukan yang belum dientri <br /> -->
		</li>
				
</ul></div>

 <form action="" method="post" enctype="multipart/form-data" name="ftbl_calonsiswa" id="ftbl_calonsiswa">
  <table width="494">
    <tr>
      <td height="17" colspan="2"><span class="style3"><strong>PILIHAN KELAS </strong></span></td>
    </tr>
    <tr>
      <td width="186" height="23"><div align="right"><span class="style3">Status Pendaftaran: </span></div></td>
      <td width="296"><span class="style3">
        <label>
        <input name="statusdaftar" value="<?php echo $statusdaftar; ?>" size="10" readonly="true">
        </label>
      </span></td>
    </tr>
    <tr>
      <td height="23"><div align="right"><span class="style3">Kelas Masuk: </span></div></td>
      <td><span class="style3">
        <label>
			<input name='kelas' value="<?php echo $kelas; ?>" size="10" readonly="true">
        </label>
      </span></td>
    </tr>
    <tr>
      <td height="23"><div align="right" class="style3">
        <div align="right">Tahun Masuk: </div>
      </div></td>
      <td><input name="thnmasuk" type="text" id="thnmasuk" size="10" value="<?php echo $thnmasuk; ?>" readonly="treu" /></td>
    </tr>
    <tr>
      <td colspan="2" class="style3"><strong>KETERANGAN TENTANG DIRI CALON
        
        SISWA </strong></td>
    </tr>
    <tr>
      <td><div align="right" class="style3">Nama Lengkap:</div></td>
      <td><input name="namalengkap" type="text" id="namalengkap" size="40" value="<?php echo $namalengkap; ?>" /></td>
    </tr>
    <tr>
      <td><div align="right" class="style3">Tempat Tanggal Lahir:</div></td>
      <td class="style3"><input name="tempatlhrsiswa" type="text" id="tempatlhrsiswa" value="<?php echo $tempatlhrsiswa; ?>" />
          <input name="tanggallhrsiswa" type="text" id="tanggallhrsiswa" size="10" value="<?php echo $tanggallhrsiswa; ?>" />
        dd/MM/yyyy</td>
    </tr>
    <tr>
      <td><div align="right" class="style3">Jenis Kelamin:</div></td>
      <td class="style3"><span class="style3">
        <select name="kelaminid" id="kelaminid">
          <option value='<?php echo $kelaminid; ?>'><?php echo $kelaminid; ?></option>
          <option value="Laki-Laki">Laki-Laki</option>
          <option value="Perempuan">Perempuan</option>         
        </select>
      </span> </td>
    </tr>
    <tr>
      <td><div align="right" class="style3">Agama:</div></td>
      <td class="style3"><span class="style3">
        <select name="agamaid" id="agamaid">
          <option value="<?php echo $agamaid; ?>"><?php echo $agamaid; ?></option>
          <option value="Islam">Islam</option>
        </select>
      </span> </td>
    </tr>
    <tr>
      <td><div align="right" class="style3">Kewarganegaran:</div></td>
      <td class="style3"><span class="style3">
        <select name="kewarganegid" id="kewarganegid">
          <option value="<?php echo $kewarganegid; ?>"><?php echo $kewarganegid; ?></option>
          <option value="WNI">WNI</option>
          <option value="WNA">WNA</option>
        </select>
      </span> </td>
    </tr>
    <tr>
      <td><div align="right" class="style3">Status Dalam Keluarga:</div></td>
      <td class="style3"><span class="style3">
        <select name="statusdiriid" id="statusdiriid">
          <option value="<?php echo $statusdiriid; ?>"><?php echo $statusdiriid; ?></option>
          <option value="Lengkap">Lengkap</option>
          <option value="Yatim">Yatim</option>
          <option value="Piatu">Piatu</option>
          <option value="Yatim Piatu">Yatim Piatu</option>
        </select>
      </span> </td>
    </tr>
     <tr>
      <td><div align="right" class="style3">Anak Ke:</div></td>
      <td class="style3"><input name="anakke" type="text" id="anakke" size="2" value="<?php echo $anakke; ?>" />
        dari
        <input name="saudarakandung" type="text" id="saudarakandung" size="2" value="<?php echo $saudarakandung; ?>" />
        Bersaudara </td>
    </tr>
    <tr>
      <td><div align="right" class="style3">Alamat Siswa:</div></td>
      <td class="style3"><span class="style3">
        <textarea name="alamatsiswa" cols="40" id="alamatsiswa"><?php echo $alamatsiswa; ?></textarea>
      </span> </td>
    </tr>
    <tr>
      <td><div align="right" class="style3">Nomor Telepon: </div></td>
      <td><input name="notelpon" type="text" id="notelpon" size="15" value="<?php echo $notelpon; ?>" /></td>
    </tr>
    
    <tr>
      <td height="26">&nbsp;</td>
      <td><span class="style3">
        <input type="submit" name="Ubah" value="Update Data" />
		<input type="reset" name="Reset" value="Reset" />
      </span></td>
    </tr>
  </table>
</form>


	<!-- UPDATE DATA -->
<?php  		
	if(isset($_POST["Ubah"])){
		$nopendaftaran=$_SESSION["KODELOG"];
		$namalengkap=$_POST["namalengkap"];
		$tempatlhrsiswa = $_POST["tempatlhrsiswa"];
		$tanggallhrsiswa=$_POST["tanggallhrsiswa"];
		$kelaminid=$_POST["kelaminid"];
		$agamaid = $_POST["agamaid"];
		$kewarganegid = $_POST["kewarganegid"];
		$statusdiriid = $_POST["statusdiriid"];
		$anakke = $_POST["anakke"];
		$saudarakandung = $_POST["saudarakandung"];
		$alamatsiswa = $_POST["alamatsiswa"];
		$notelpon = $_POST["notelpon"];
		$statusdaftar=$_POST["statusdaftar"];
		$kelas=$_POST["kelas"];
		$thnmasuk=$_POST["thnmasuk"];
	//	$password=$_POST["passwrod"];
		
		$sql="update tbl_calonsiswa set  f_namalengkap='$namalengkap', f_tempatlhrsiswa='$tempatlhrsiswa', f_tanggallhrsiswa='$tanggallhrsiswa', f_kelamin='$kelaminid', f_agama='$agamaid',f_kewarganeg='$kewarganegid',f_statusdiri='$statusdiriid',f_anakke='$anakke',
f_saudarakandung='$saudarakandung', f_alamatsiswa='$alamatsiswa', f_notelpon='$notelpon' where f_nopendaftaran='$nopendaftaran' ";
	
		$hasil=mysql_query($sql);
		if($hasil){
			echo"<script>alert('PERUBAHAN DATA BERHASIL');document.location.href='?mnu=fcalonsiswaedit';</script>";
		}
		else{
			echo"<script>alert('PERUBAHAN DATA GAGAL');document.location.href='?mnu=fcalonsiswaedit';</script>";
		}
	}
?>
