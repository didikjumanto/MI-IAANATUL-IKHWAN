<?php
mysql_connect("localhost","root","");
mysql_select_db("db_psbnew");
	$sql="select * from  tbl_psbsetup ";
	$hasil=mysql_query($sql);
	$d=mysql_fetch_array($hasil);
		$thajaran=$d["f_angkatanpsb"];
		$ketuapanitia = $d["f_ketuapanitia"];

require('fpdf.php');
class PDF extends FPDF{
	function Header(){
		$this->Image('Logo MI Iaanatul Ikhwan.jpg',5,4,-500);
		$this->SetFont('Arial','B',10);
		//$this->SetTextColor(128,50,50);
		$this->text(43,8,'YAYASAN PENDIDIKAN ISLAM I�AANATUL IKHWAN (YPII) KAMPUNG SERAB');
		$this->setFont('Arial','',15);
		$this->text(50,13,'MADRASAH IBTIDAIYAH I�AANATUL IKHWAN');
		$this->setFont('Arial','',18);
		$this->text(60,20,'STATUS : TERAKREDITASI.B');
		$this->setFont('Arial','',9);
		$this->text(32,25,'Alamat : Jl.Masjid Al-Ikhwan No.12 Kp.Serab Kel.Tirtajaya Kec.Sukmajaya Kota Depok Telp.021.77820520');
		$this->text(5,28,'============================================================================================================');
	}
	function Footer(){
		// Position at 1.5 cm from bottom
		$q=mysql_query('select * from tbl_psbsetup ');
		$d=mysql_fetch_array($q);
		$this->SetY(-15);
		$this->SetFont('Arial','I',8);
		$this->Cell(0,10,'Panitia Penerimaan Siswa/siswi Baru MI Iaanatul Ikhwan Depok',0,0,'C');
		$this->Cell(0,10,'Page '.$this->PageNo(),0,0,'C');
	}
}

$tgl = date('d/M/Y');
$pdf = new PDF();
$pdf->Open();
$pdf->addPage();
$pdf->setAutoPageBreak(false);

$pdf->setFont('Arial','',12);
$pdf->text(45,32,'CALON SISWA BARU YANG MENDAFTAR TAHUN AJARAN '.$thajaran);

$yi = 41;
$ya = 35;
$pdf->setFont('Arial','',9);
$pdf->setFillColor(222,222,222);
$pdf->setXY(5,$ya);
$pdf->CELL(6,6,'NO',1,0,'C',1);
$pdf->CELL(17,6,'NO PEND',1,0,'C',1);
$pdf->CELL(40,6,'NAMA SISWA',1,0,'C',1);
$pdf->CELL(40,6,'TGL LAHIR',1,0,'C',1);
$pdf->CELL(70,6,'ALAMAT',1,0,'C',1);
$pdf->CELL(27,6,'NOMOR TELP',1,0,'C',1);
$ya = $yi + $row;
$sql = mysql_query("select * from  tbl_calonsiswa, tbl_psbsetup  ");
$i = 1;
$no = 1;
$max = 31;
$row = 6;
while($data = mysql_fetch_array($sql)){
$pdf->setXY(5,$ya);
$pdf->setFont('arial','',9);
$pdf->setFillColor(255,255,255);
$pdf->cell(6,6,$no,1,0,'C',1);
$pdf->cell(17,6,$data[f_nopendaftaran],1,0,'L',1);
$pdf->cell(40,6,$data[f_namalengkap],1,0,'L',1);
$pdf->CELL(40,6,$data[f_tanggallhrsiswa],1,0,'C',1);
$pdf->CELL(70,6,$data[f_alamatsiswa],1,0,'C',1);
$pdf->CELL(27,6,$data[f_notelpon],1,0,'C',1);
$ya = $ya+$row;
$no++;
$i++;
$ketua = $data[f_ketuapanitia];
}
$pdf->text(140,$ya+6,"DEPOK , ".$tgl);
$pdf->text(140,$ya+21,$ketua);
$pdf->output();
?>