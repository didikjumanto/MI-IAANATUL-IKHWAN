<?php
mysql_connect("localhost","root","");
mysql_select_db("db_psbnew");
	$sql="select * from  tbl_psbsetup ";
	$hasil=mysql_query($sql);
	$d=mysql_fetch_array($hasil);
		$thajaran=$d["f_angkatanpsb"];
		$ketuapanitia = $d["f_ketuapanitia"];

require('fpdf.php');
class PDF extends FPDF{
	function Header(){
		$this->Image('Logo MI Iaanatul Ikhwan.jpg',5,4,-500);
		$this->SetFont('Arial','B',10);
		//$this->SetTextColor(128,50,50);
		$this->text(43,8,'YAYASAN PENDIDIKAN ISLAM I�AANATUL IKHWAN (YPII) KAMPUNG SERAB');
		$this->setFont('Arial','',15);
		$this->text(50,13,'MADRASAH IBTIDAIYAH I�AANATUL IKHWAN');
		$this->setFont('Arial','',18);
		$this->text(60,20,'STATUS : TERAKREDITASI.B');
		$this->setFont('Arial','',9);
		$this->text(32,25,'Alamat : Jl.Masjid Al-Ikhwan No.12 Kp.Serab Kel.Tirtajaya Kec.Sukmajaya Kota Depok Telp.021.77820520');
		$this->text(5,28,'============================================================================================================');
	}
	function Footer(){
		// Position at 1.5 cm from bottom
		$q=mysql_query('select * from tbl_psbsetup ');
		$d=mysql_fetch_array($q);
		$this->SetY(-15);
		$this->SetFont('Arial','I',8);
		$this->Cell(0,10,'Panitia Penerimaan Siswa/siswi Baru MI Iaanatul Ikhwan Depok',0,0,'C');
		$this->Cell(0,10,'Page '.$this->PageNo(),0,0,'C');
	}
}

$tgl = date('d/M/Y');
$pdf = new PDF();
$pdf->Open();
$pdf->addPage();
$pdf->setAutoPageBreak(false);

$pdf->setFont('Arial','',12);
$pdf->text(70,32,'BUKTI KONFIRMASI PEMBAYARAN');

$yi = 41;
$ya = 35;
$pdf->setFont('Arial','',9);
$pdf->setFillColor(222,222,222);
$pdf->setXY(5,$ya);


$pdf->text(6,50,'No. Urut Pendaftaran',1,0,'C',1);
$pdf->text(6,60,'No. Pendaftaran',1,0,'C',1);
$pdf->text(6,70,'Atas Nama',1,0,'C',1);
$pdf->text(6,80,'No. Rekening',1,0,'C',1);
$pdf->text(6,90,'Nominal',1,0,'C',1);
$pdf->text(6,100,'Email',1,0,'C',1);
$data = mysql_fetch_array(mysql_query("select * from tbl_konfirmasi, tbl_psbsetup where f_nopendaftaran='$_GET[no_konfirmasi]'"));

$pdf->setFont('arial','',9);
$pdf->setFillColor(255,255,255);

$pdf->text(70,50,": $data[no_urut]",1,0,'L',1);
$pdf->text(70,60,": $data[f_nopendaftaran]",1,0,'L',1);
$pdf->text(70,70,": $data[atas_nama]",1,0,'C',1);
$pdf->text(70,80,": $data[no_rekening]",1,0,'C',1);
$pdf->text(70,90,": $data[nominal]",1,0,'L',1);
$pdf->text(70,100,": $data[email]",1,0,'L',1);

$pdf->text(140,120,"DEPOK , ".$tgl);
$pdf->text(140,125,"Panitia PSB, ");
$pdf->text(140,150,"Didik Jumanto");

$pdf->text(50,240,'   Lampiran ini adalah bukti yang sah bahwa calon siswa telah melakukan',1,0,'C',1);
$pdf->text(60,245,'                          konfirmasi pembayaran',1,0,'C',1);
$pdf->text(50,255,'             Harap Print Out Halaman ini sebagai Bukti Pembayaran !',1,0,'C',1);
$pdf->output();
?>