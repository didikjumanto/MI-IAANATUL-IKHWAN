<?php
$PATHJAVASCRIPT="scripts";
?>

<link type="text/css" href="<?php echo "$PATHJAVASCRIPT/base/";?>ui.all.css" rel="stylesheet" />   
<script type="text/javascript" src="<?php echo "$PATHJAVASCRIPT/";?>jquery-1.3.2.js"></script>
<script type="text/javascript" src="<?php echo "$PATHJAVASCRIPT/";?>ui/ui.core.js"></script>
<script type="text/javascript" src="<?php echo "$PATHJAVASCRIPT/";?>ui/ui.datepicker.js"></script>
<script type="text/javascript" src="<?php echo "$PATHJAVASCRIPT/";?>ui/i18n/ui.datepicker-id.js"></script>    
  <script type="text/javascript"> 
      $(document).ready(function(){
        $("#tanggalsttb").datepicker({
					dateFormat  : "dd/MM/yy",        
          changeMonth : true,
          changeYear  : true					
        });
      });
    </script>  
	
<style type="text/css">
<!--
.style3 {font-size: 12px}
.style4 {color: #FF0000}
-->
</style>

 
<form action="" method="post" enctype="multipart/form-data" name="tbl_konfirmasi" id="tbl_konfirmasi">
  <table width="494">
    <tr>
      <td colspan="2"><span class="style3"><strong>KONFIRMASI PEMBAYARAN </strong></span></td>
    </tr>
    <tr>
      <td width="186"><div align="right" class="style3">
          <div align="left">No. Urut Pendaftaran: </div>
      </div></td>
      <td width="296"><input name="urutpendaftaran" type="text" id="urutpendaftaran" size="10"/></td>
    </tr>
    <tr>
      <td><div align="left" class="style3">
          <div align="left">No. Pendaftaran: </div>
      </div></td>
      <td class="style3"><input name="nopendaftaran" type="text" id="nopendaftaran" size="40" /></td>
    </tr>
	 <tr>
      <td><div align="right" class="style3">
          <div align="left">Atas Nama Rekening: </div>
      </div></td>
      <td class="style3"><input name="atasnama" type="text" id="atasnama"/></td>
    </tr>
    <tr>
      <td><div align="right" class="style3">
          <div align="left">No. Rekening: </div>
      </div></td>
      <td class="style3"><input name="norekening" type="text" id="norekening"/></td>
    </tr>
    <tr>
      <td><div align="right" class="style3">
          <div align="left">Nominal: </div>
      </div></td>
      <td><input name="nominal" type="text" id="nominal" size="40"/></td>
    </tr>
       <tr>
      <td><div align="right" class="style3">
          <div align="left">Email: </div>
      </div></td>
      <td><input name="email" type="text" id="email" size="40"/></td>
    </tr>
	<tr>
      <td height="26">&nbsp;</td>
    <td>
        <input type="submit" name="Simpan" value="Proses Konfirmasi" />
    </tr>
  </table>

</form>

	<p>
  <!-- MENGUPDATE DATA  -->
  <?php 
	$kd_transaksi=$_SESSION["KODELOG"];
	if(isset($_POST["Simpan"])){
		$no_urut = $_POST["urutpendaftaran"];
		$no_daftar = $_POST["nopendaftaran"];
		$atas_nama = $_POST["atasnama"];
		$no_rekening = $_POST["norekening"];
		$nominal =$_POST["nominal"];
		$email = $_POST["email"]; 
		
		
		$sql_query="select * from tbl_calonsiswa where f_nopendaftaran='$no_daftar'";
		$q=mysql_query($sql_query);
		$jum=mysql_num_rows($q);
		
		if($jum > 0){

				if($hasil){
				$sql_insert="INSERT INTO `db_psbnew`.`tbl_konfirmasi` (`no_urut`, `f_nopendaftaran`, `atas_nama`, `no_rekening`, `nominal`, `email`) VALUES ('$no_urut', '$no_daftar', '$atas_nama', '$no_rekening', '$nominal', '$email')";
				
				$hasil=mysql_query($sql_insert);
				
				/*--------------fungsi kirim email-----*/
				$sql="SELECT * FROM  `tbl_calonsiswa` where f_nopendaftaran='$no_daftar'";
				$hasil=mysql_query($sql);
				$d=mysql_fetch_array($hasil);
				
				$to= $email;
				$pesan="Terima kasih Calon Siswa/Siswi ".$d['f_namalengkap']." telah melakukan konfirmasi pembayaran,
				
No.Pendaftaran :  ".$d['f_nopendaftaran']."
Password 	   :  ".$d['f_password']."

Silahkan gunakan No. Pendaftaran dan Password anda untuk masuk ke halaman website kami untuk memperbaharui data anda.
Terima kasih

  
Tim Psb MI
";
				$subject="Tim Psb MI Iaanatul Ikhwan";
				$kirim=mail($to,$subject,$pesan);
				
				if($kirim){
					echo"berhasil terkirim";
					}else{echo"gagal";}
				
				
				
				/*--------end---------*/
				
				
				
					echo"<script>alert('Data berhasil disimpan !! Terima kasih telah melakukan konfirmasi pembayaran. Silahkan cek Email anda untuk mendapatkan No. Pendaftaran dan Password untuk bisa masuk ke dalam web calon siswa.');document.location.href='system/report/buktikonfirmasi.php?no_konfirmasi=$no_daftar';</script>";
				}
				
		}

		else{
		
			echo"<script>alert('DATA TIDAK TERDAFTAR, SILAHKAN CEK KEMBALI NOMOR PENDAFTARAN ANDA, TERIMA KASIH :) ');document.location.href='?mnu=konfirmasi';</script>";
		}
		
		
	}
	
  
?>
