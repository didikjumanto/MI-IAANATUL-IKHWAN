<?php 
	$FTSWA="fotocalonsiswa";	
	if(!$_SESSION["1CLEVEL"]==""){

?>
<style type="text/css">
<!--
.style1 {color: #FFFFFF}
-->
</style>

<meta http-equiv="refresh" content="10">
<h2>DAFTAR LAMPIRAN CALON SISWA </h2>
	
<table width="70%" border="1">
  <tr bgcolor="#60D6FA">
    <th width="3%" bgcolor="#333333"><span class="style1">No.</span></th>
    <th width="9%" bgcolor="#333333"><span class="style1">Pendaftaran</span></th>
    <th width="53%" bgcolor="#333333"><span class="style1">Nama Siswa </span></th>
    <th width="8%" bgcolor="#333333"><span class="style1">Foto</span></th>
    <th width="6%" bgcolor="#333333"><span class="style1">SKTB</span></th>
    <th width="5%" bgcolor="#333333"><span class="style1">Akte</span></th>
  </tr>

<?php  
	#	mysql_connect("localhost","root","");
	#	mysql_select_db("db_psbnew");
	$s="select * from tbl_calonsiswa  order by f_nopendaftaran asc ";
	$q=mysql_query($s);
	$jum=mysql_num_rows($q);
		if($jum > 0){
			$batas   = 10;
			$page = $_GET['page'];
			if(empty($page)){
				$posawal  = 0;$page = 1;
			}
			else{
				$posawal = ($page-1) * $batas;
			}
			$s2 = $s." LIMIT $posawal,$batas";
			$q2  = mysql_query($s2);
			$no = $posawal+1;
			
			while($d=mysql_fetch_array($q2)){							
				$nopendafaran=$d["f_nopendaftaran"];
				$namalengkap=$d["f_namalengkap"];
				$foto=$d["f_foto"];
				$sktb=$d["f_sktb"];
				$akte=$d["f_aktekel"];
				
				if($no %2==1){
					echo"<tr bgcolor='#99FF33'>
						<td>$no</td>
						<td>$nopendafaran</td>
						<td>$namalengkap</td>
						<td><center><a href='$FTSWA/$foto' class='link' title='$namalengkap' rel='prettyPhoto[gallery1]'><img src='$FTSWA/$foto' width='70' height='70' /></a></center></td>
						<td><center><a href='$FTSWA/$sktb' class='link' title='$namalengkap' rel='prettyPhoto[gallery1]'><img src='$FTSWA/$sktb' width='70' height='70' /></a></center></td>
						<td><center><a href='$FTSWA/$akte' class='link' title='$namalengkap' rel='prettyPhoto[gallery1]'><img src='$FTSWA/$akte' width='70' height='70' /></a></center></td></center>
					</tr>";
				}//no==1
				else if($no %2==0){
					echo"<tr bgcolor='#FFFF99'>
						<td>$no</td>
						<td>$nopendafaran</td>
						<td>$namalengkap</td>
						<td><center><a href='$FTSWA/$foto' class='link' title='$namalengkap' rel='prettyPhoto[gallery1]'><img src='$FTSWA/$foto' width='70' height='70' /></a></center></td>
						<td><center><a href='$FTSWA/$sktb' class='link' title='$namalengkap' rel='prettyPhoto[gallery1]'><img src='$FTSWA/$sktb' width='70' height='70' /></a></center></td>
						<td><center><a href='$FTSWA/$akte' class='link' title='$namalengkap' rel='prettyPhoto[gallery1]'><img src='$FTSWA/$akte' width='70' height='70' /></a></center></td></center>
					</tr>";
				}
				$no++;
			}
		}
		
?>
</table>


<?php 


}//if Administrator
?>



