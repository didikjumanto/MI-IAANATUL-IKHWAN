<!-- 
<?php
$PATHJAVASCRIPT="scripts";
?>

<link type="text/css" href="<?php echo "$PATHJAVASCRIPT/base/";?>ui.all.css" rel="stylesheet" />   
<script type="text/javascript" src="<?php echo "$PATHJAVASCRIPT/";?>jquery-1.3.2.js"></script>
<script type="text/javascript" src="<?php echo "$PATHJAVASCRIPT/";?>ui/ui.core.js"></script>
<script type="text/javascript" src="<?php echo "$PATHJAVASCRIPT/";?>ui/ui.datepicker.js"></script>
<script type="text/javascript" src="<?php echo "$PATHJAVASCRIPT/";?>ui/i18n/ui.datepicker-id.js"></script>    
	<script type="text/javascript">
$(document).ready(function() {
		 $("#tanggallhrsiswa").datepicker({
					dateFormat  : "dd MM yy",        
          changeMonth : true,
          changeYear  : true					
        });
})
</script>
-->
<!-- form validation -->
<script type="text/javascript" src="scripts/validation/jquery-1.2.3.pack.js"></script>
<script type="text/javascript" src="scripts/validation/jquery.validate.pack.js"></script>
<script type="text/javascript">
$(document).ready(function() {
	$("#ftbl_calonsiswa").validate({
		messages: {
		},
		errorPlacement: function(error, element) {
			error.appendTo(element.parent("td"));
		}
	});
})
</script>
	
<style type="text/css">
<!--
.style3 {font-size: 12px}
.style4 {
	font-size: 24px;
	font-weight: bold;
}
-->
</style><?php 
	//LOAD DATA PMB SETUP
	$sql212="select * from  tbl_psbsetup ";
	$hasil212=mysql_query($sql212);
	$data212=mysql_fetch_array($hasil212);
		$angkatanpsb = $data212["f_angkatanpsb"];
		$semester = $data212["f_semester"];
		$ketuapanitia=$data212["f_ketuapanitia"];

	//PEMBERSIHAN DATA DARI INPUTAN
	$nopendaftaran ="";
	$namalengkap="";
	$tempatlhrsiswa ="";
	$tanggallhrsiswa="";
	$kelaminid="";
	$agamaid ="";
	$kewarganegid ="";
	$statusdiriid ="";
	$anakke ="";
	$saudarakandung ="";
	$alamatsiswa ="";
	$notelpon ="";
	$statusdaftar="";
	$kelas="";
//	$thnmasuk="";
//	$password=$_POST["passwrod"];

//NGETES AJAH

?>

<h2>Formulir Isian Pendaftaran Calon Siswa Baru</h2>
 <form action="" method="post" enctype="multipart/form-data" name="ftbl_calonsiswa" id="ftbl_calonsiswa" >
  <table width="494">
    <tr>
      <td height="17" colspan="2"><div align="center" class="style4">DATA SISWA/SISWI BARU </div></td>
    </tr>
    <tr>
      <td width="186" height="23"><div align="left"><span class="style3">Status Pendaftaran: </span></div></td>
      <td width="296">        
        <select name="statusdaftar" class="required" title="harus diisi">
          <option value="">- Pilih Status Daftar -</option>
          <option value="BARU">Daftar Baru</option>
          <option value="PINDAHAN">Daftar Pindahan</option>
        </select>      </td>
    </tr>
    <tr>
<!-- 	<?php 	$statusdaftar1=$_POST[statusdaftar]; ?><input name="stsdaftar" type="text" value="<?php echo $statusdaftar1;?>" /> -->
      <td height="23"><div align="left"><span class="style3">Kelas Masuk: </span></div></td>
      <td>        
        <select name="kelas" class="required" title="harus diisi">
          <option value="">- Pilih -</option>
		 <?php
		$perintah="select * from tbl_kelas ";//where f_key %like% '$statusdaftar1' ";
		$lihat=mysql_query($perintah);
		while ($data=mysql_fetch_array($lihat)){
			$kelas=$data["f_kelas"];
			echo" <option value='$kelas'>$kelas</option>";
		}
		?>
		</select>      </td>
    </tr>
    <tr>
      <td height="23"><div align="right" class="style3">
        <div align="left">Tahun Masuk: </div>
      </div></td>
      <td><input name="thnmasuk" type="text" id="thnmasuk" size="10" value="<?php echo $angkatanpsb;?>" readonly="true" /></td>
    </tr>
    
    <tr>
      <td><div align="right" class="style3">
        <div align="left">Nama Lengkap:</div>
      </div></td>
      <td><input name="namalengkap" type="text" id="namalengkap" size="40" class="required" title="harus diisi" /></td>
    </tr>
    <tr>
      <td><div align="right" class="style3">
        <div align="left">Tempat Tanggal Lahir:</div>
      </div></td>
      <td class="style3"><input name="tempatlhrsiswa" type="text" id="tempatlhrsiswa" class="required" title="harus diisi" />
          <input name="tanggallhrsiswa" type="text" id="tanggallhrsiswa" size="10" class="required" title=" "  />
        dd/MM/yyyy</td>
    </tr>
    <tr>
      <td><div align="right" class="style3">
        <div align="left">Jenis Kelamin:</div>
      </div></td>
      <td class="style3">
        <select name="kelaminid" id="kelaminid" class="required" title="harus diisi">
          <option value=''>- Pilih -</option>
          <option value="Laki-Laki">Laki-Laki</option>
          <option value="Perempuan">Perempuan</option>         
        </select>      </td>
    </tr>
    <tr>
      <td><div align="right" class="style3">
        <div align="left">Agama:</div>
      </div></td>
      <td class="style3">
        <select name="agamaid" id="agamaid" class="required" title="harus diisi">
          <option value="">- Pilih -</option>
          <option value="Islam">Islam</option>
        </select>      </td>
    </tr>
    <tr>
      <td><div align="right" class="style3">
        <div align="left">Kewarganegaran:</div>
      </div></td>
      <td class="style3">
        <select name="kewarganegid" id="kewarganegid" class="required" title="harus diisi">
          <option value="">- Pilih -</option>
          <option value="WNI">WNI</option>
          <option value="WNA">WNA</option>
        </select>      </td>
    </tr>
    <tr>
      <td><div align="right" class="style3">
        <div align="left">Status Dalam Keluarga:</div>
      </div></td>
      <td class="style3">
        <select name="statusdiriid" id="statusdiriid" class="required" title="harus diisi">
          <option value="">- Pilih -</option>
          <option value="Lengkap">Anak Kandung</option>
          <option value="Yatim">Anak Tiri</option>
          <option value="Piatu">Anak pungut</option>
        </select>      </td>
    </tr>
    <tr>
      <td><div align="right" class="style3">
        <div align="left">Anak Ke:</div>
      </div></td>
      <td class="style3"><input name="anakke" type="text" id="anakke" size="2" class="required" title="harus diisi" />
        Dari
          <input name="saudarakandung" type="text" id="saudarakandung" size="2" class="required" title=" " />
Bersaudara </td>
    </tr>
    
    <tr>
      <td><div align="right" class="style3">
        <div align="left">Alamat Siswa:</div>
      </td>
      <td class="style3">
        <textarea name="alamatsiswa" cols="40" id="alamatsiswa" class="required" title="harus diisi"></textarea>      </td>
    </tr>
    <tr>
      <td><div align="right" class="style3">
        <div align="left">Nomor Telepon: </div>
      </div></td>
      <td><input name="notelpon" type="text" id="notelpon" size="15" /></td>
    </tr>
    <tr>
      <td height="26">&nbsp;</td>
      <td>
        <input type="submit" name="Simpan" value="Proses Pendaftaran" />
        <input type="reset" name="Reset" value="Reset" />      </td>
    </tr>
  </table>
</form>


<!-- SIMPAN DATA PENDAFTARAN  -->
<?php  		
if(isset($_POST["Simpan"])){	
	//KODE NOPENDAFTARAN
	$sql1="select * from tbl_calonsiswa order by f_nopendaftaran desc";
	$q=mysql_query($sql1);
	$jum=mysql_num_rows($q);
	$kd="N".date("y").date("m");
		if($jum > 0){
			$d=mysql_fetch_array($q);
			$nopendaftaran=$d["f_nopendaftaran"];
			$urut=substr($nopendaftaran,5,4)+1;
			if($urut<10){$nopendaftaran="$kd"."00".$urut;}
			else if($urut<100){$nopendaftaran="$kd"."0".$urut;}
			else{$nopendaftaran="$kd".$urut;}
		}
		else{
			$nopendaftaran="$kd"."001";
		}		
	//PASSWORD
	$password = substr(md5(uniqid('')),-5,5);
	$_SESSION['captcha_session'] = $password;
	
	$namalengkap=$_POST["namalengkap"];
	$tempatlhrsiswa = $_POST["tempatlhrsiswa"];
	$tanggallhrsiswa=$_POST["tanggallhrsiswa"];
	$kelaminid=$_POST["kelaminid"];
	$agamaid = $_POST["agamaid"];
	$kewarganegid = $_POST["kewarganegid"];
	$statusdiriid = $_POST["statusdiriid"];
	$anakke = $_POST["anakke"];
	$saudarakandung = $_POST["saudarakandung"];
	$alamatsiswa = $_POST["alamatsiswa"];
	$notelpon = $_POST["notelpon"];
	$statusdaftar=$_POST["statusdaftar"];
	$kelas=$_POST["kelas"];
	$thnmasuk=$_POST["thnmasuk"];	
	$sql="insert into tbl_calonsiswa(f_nopendaftaran, 
									 f_namalengkap, 
									 f_tempatlhrsiswa, 
									 f_tanggallhrsiswa, 
									 f_kelamin, 
									 f_agama,
									 f_kewarganeg, 
									 f_statusdiri, 
									 f_anakke, 
									 f_saudarakandung,
									 f_alamatsiswa,
									 f_notelpon,
									 f_statusdaftar,
									 f_kelas,
									 f_thnmasuk,
									 f_password)
									 
	values('$nopendaftaran','$namalengkap','$tempatlhrsiswa','$tanggallhrsiswa','$kelaminid', '$agamaid', '$kewarganegid', '$statusdiriid','$anakke','$saudarakandung','$alamatsiswa','$notelpon','$statusdaftar','$kelas','$thnmasuk','$password')";
		$hasil=mysql_query($sql);
	if($hasil){
		
		echo"<script>alert('Data berhasil disimpan.');document.location.href='system/report/buktipendaftaran.php?no_daftar=$nopendaftaran';</script>";
	}
	else{
		echo"<script>alert('Proses pendaftaran gagal, silahkan coba lagi');document.location.href='fregistrasinew.php';</script>";
	}
}  
?>
