<style type="text/css">
<!--
.style1 {
	font-size: 24px;
	font-weight: bold;
}
-->
</style>
<table width="414" border="5">
  <tr>
    <td colspan="3"><div align="center" class="style1">Rincian Biaya Pendaftaran </div></td>
  </tr>
  <tr>
    <td width="8">1</td>
    <td width="109">Iuran bulanan/SPP</td>
    <td width="81">Rp.  20.000</td>
  </tr>
  <tr>
    <td>2</td>
    <td>Seragam</td>
    <td>Rp. 175.000</td>
  </tr>
  <tr>
    <td>3</td>
    <td>Biaya Gedung </td>
    <td>Rp. 275.000</td>
  </tr>
  <tr>
    <td colspan="2"><div align="right">Jumlah</div></td>
    <td>Rp. 470.000</td>
  </tr>
</table>

<table width="447" height="132" border="5">
  <tr>
    <td colspan="3"><div align="center"><span class="style1">Persyaratan Pendaftaran Siswa Baru </span></div></td>
  </tr>
  <tr>
    <td width="67">1</td>
    <td width="98"><p>Akte Kelahiran </p>
    </td>
    <td width="152">1 Lembar </td>
  </tr>
  <tr>
    <td>2</td>
    <td>Foto Copy SKTB </td>
    <td>2 Lembar </td>
  </tr>
  <tr>
    <td>3</td>
    <td>Foto Ukuran 3x4 </td>
    <td>2 Lembar </td>
  </tr>
</table>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp; </p>
