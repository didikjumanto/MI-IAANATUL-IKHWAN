<?php
	session_start();
	include "koneksi.php";
	$mnu=$_GET["mnu"];	
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="EN" lang="EN" dir="ltr">
<head profile="http://gmpg.org/xfn/11">
<title>MI IAANATUL IKHWAN</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<meta http-equiv="imagetoolbar" content="no" />
<link rel="stylesheet" href="styles/layout.css" type="text/css" /> 
<script type="text/javascript" src="scripts/jquery-1.4.1.min.js"></script>
<script type="text/javascript" src="scripts/jquery.defaultvalue.js"></script>
<script type="text/javascript" src="scripts/jquery-ui-1.8.13.custom.min.js"></script>
<script type="text/javascript" src="scripts/jquery.scrollTo-min.js"></script>
<script type="text/javascript">
$(document).ready(function () {
    $("#fullname, #validemail, #message").defaultvalue("Full Name", "Email Address", "Message");
    $('#shout a').click(function () {
        var to = $(this).attr('href');
        $.scrollTo(to, 1200);
        return false;
    });
    $('a.topOfPage').click(function () {
        $.scrollTo(0, 1200);
        return false;
    });
    $("#tabcontainer").tabs({
        event: "click"
    });
    $("a[rel^='prettyPhoto']").prettyPhoto({
        theme: 'dark_rounded'
    });
});
</script>
<link rel="stylesheet" href="styles/prettyPhoto.css" type="text/css" />
<style type="text/css">
.style192 {font-family: "Times New Roman", Times, serif}
.style1911 {font-family: "Times New Roman", Times, serif}
body {
	background-color: #FFF;
	background-image: url(images/classic-spiral2.jpg);
	background-repeat: repeat;
}
</style>
<script type="text/javascript" src="scripts/jquery-prettyPhoto.js"></script>	
</head>
<body id="top">
<div id="header">
  <div class="wrapper">
    <div class="fl_right"><img src="infoimages/default.png" width="70" height="70" /></div>
    <div class="fl_left">
      <h1>MI I'AANATUL IKHWAN</h1>
      <p>Jl. Masjid Al-Ikhwan Kp. Parung Serab Rt 05/03 Kel. Tirtajaya Kec. Sukmajaya Kota Depok 16412</p>
    </div>
    <br class="clear" />
  </div>
</div>
<!-- ####################################################################################################### -->
<div id="topbar">
  <div class="wrapper">
    <div id="topnav">
      <ul>
 	<?php if($_SESSION["1CLEVEL"]=="admin"){?> 
        <li><a href="?mnu=fpsbsetup">pengaturan</a></li>
        <li><a href="?mnu=user">pengguna</a></li>
		<li><a href="?mnu=finformasi">informasi</a></li>
        <li><a href="?mnu=ffotocalonsiswa">lampiran</a></li>
		<li><a href="#">laporan</a>
          <ul>
            <li><a href="system/report/calonsiswa.php">siswa yang mendaftar</a></li>
            <li><a href="system/report/pembayaran.php">bukti konfirmasi pembayaran</a></li>
          </ul>
        </li>				
        <li><a href="?mnu=userpassword">kata sandi</a></li>
	    <li><a href="?mnu=keluar">keluar</a></li>
	    <?php } else if($_SESSION["1CLEVEL"]=="user"){?>
        <li><a href="?mnu=ffotocalonsiswa">foto</a></li>
		<li><a href="?mnu=finformasi">informasi</a></li>
          <ul>
            <li><a href="system/report/calonsiswa.php">siswa yang mendaftar</a></li>
            <li><a href="system/report/pembayaran.php">bukti konfirmasi pembayaran</a></li>
          </ul>
        </li>				
        <li><a href="?mnu=userpassword">kata sandi</a></li>
	   <li><a href="?mnu=keluar">keluar</a></li>
	   <?php }
		//	else if($_SESSION["1CLEVEL"]<>"user" || $_SESSION["1CLEVEL"]<>"admin"){}	
	?>
      </ul>
    </div>
   
    <br class="clear" />
  </div>
</div>
<!-- ####################################################################################################### -->
<div id="breadcrumb">
  <div class="wrapper">
    <ul>
	<marquee style="color: #413D3D;"> 
		<em>Selamat Datang <? echo $_SESSION["1CNAMA"] ;?>, di Administrator Website Penerimaan Siswa Baru<b> MI I'AANATUL IKHWAN </b>Depok</em>
	</marquee>
    </ul>
  </div>
</div>
<!-- ####################################################################################################### -->
<div id="container">
  <div class="wrapper">

   <?php $mnu=$_GET["mnu"]; 
		if ($mnu=="finformasi"){ include"system/adminsystem/finformasi.php";}
		else if($mnu=="fpsbsetup"){include"system/adminsystem/fpsbsetup.php";}
		else if($mnu=="fcalonsiswa"){include "system/adminsystem/fcalonsiswa.php";}
		else if($mnu=="ffotocalonsiswa"){include "system/adminsystem/ffotocalonsiswa.php";}
		else if($mnu=="user"){include"system/adminsystem/user.php";}
		else if($mnu=="userpassword"){include"system/adminsystem/userpassword.php";}
		else{	?>
		<!-- DAPAT DIISI DENGAN CONTENT APA SAJA -->
<h2>MI I'AANATUL IKHWAN</h2>
<p class="Default"><strong>1. &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Visi Sekolah</strong>&nbsp;</p>
<p class="Default">Membentuk peserta didik yang menguasai IPTEK, berwawasan IMTAQ dengan tidak mengesampingkan kebutuhan Sumber Daya Manusia di lingkungan Masyarakat. </p>
<p class="Default"><strong>2. &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Misi Sekolah</strong>&nbsp;</p>
<p class="Default">MI I'aanatul Ikhwan memiliki misi  sebagai berikut:</p>
<ol start="1" type="1" class="style1911">
  <li>Kokoh dan tangguh menjalankan syariat islam </li>
  <li>Bersaing dan unggul meraih prestasi </li>
  <li>Berbudi pekerti dan berakhlak mulia </li>
  <li>Berguna dan dibutuhkan kiprahnya didalam masyarakat</li>
  <li>Menjadi generasi yang sehat jasmani dan rohani, tidak terkontaminasi  narkoba</li>
  <li>Peduli terhadap lingkungan dan mandiri</li>
</ol>
<p class="Default"></p>

	<?php } ?>
	
	
  </div>
</div>
<!-- ####################################################################################################### -->

<!-- ####################################################################################################### -->
<div id="copyright">
  <div class="wrapper">
    <p class="fl_right">
		<?php if($_SESSION["1CLEVEL"]=="admin" || $_SESSION["1CLEVEL"]=="user"){?> 
		<a href="?mnu=keluar" title="Log Out"><?php echo $_SESSION["1CNAMA"] ; ?></a>
		<?php }	
		else{echo "masuk <a href='login.php' title='masuk administrator'>administrator</a>";}
		?>		
	</p>
    <br class="clear" />
  </div>
</div>
</body>
</html>


<?php	//	LOGOUT
	if($mnu=="keluar"){
		session_destroy();
		echo "<script>alert('TERIMAKASIH ATAS PARTISIPASINYA');document.location.href='index.php';</script>";
	}
?>

