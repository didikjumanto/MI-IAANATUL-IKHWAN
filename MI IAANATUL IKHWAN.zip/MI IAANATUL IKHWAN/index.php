<?php
	session_start();
	require_once "koneksi.php";
	$mnu=$_GET["mnu"];	
?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="EN" lang="EN" dir="ltr">
<head profile="http://gmpg.org/xfn/11">
<title>MI IAANATUL IKHWAN</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<meta http-equiv="imagetoolbar" content="no" />
<link rel="stylesheet" href="styles/layout.css" type="text/css" /> 
<script type="text/javascript" src="scripts/jquery-1.4.1.min.js"></script>
<script type="text/javascript" src="scripts/jquery.defaultvalue.js"></script>
<script type="text/javascript" src="scripts/jquery-ui-1.8.13.custom.min.js"></script>
<script type="text/javascript" src="scripts/jquery.scrollTo-min.js"></script>
<script type="text/javascript">
$(document).ready(function () {
    $("#fullname, #validemail, #message").defaultvalue("Full Name", "Email Address", "Message");
    $('#shout a').click(function () {
        var to = $(this).attr('href');
        $.scrollTo(to, 1200);
        return false;
    });
    $('a.topOfPage').click(function () {
        $.scrollTo(0, 1200);
        return false;
    });
    $("#tabcontainer").tabs({
        event: "click"
    });
    $("a[rel^='prettyPhoto']").prettyPhoto({
        theme: 'dark_rounded'
    });
});
</script>
<link rel="stylesheet" href="styles/prettyPhoto.css" type="text/css" />
<style type="text/css">
.style191 {font-family: "Times New Roman", Times, serif}
.style20 {color: #33FF00}
.style21 {
	font-size: 16px;
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-weight: bold;
	color: #00FF99;
}
.style22 {
	font-size: 16px;
	color: #00FF99;
}
body {
	background-color:"";
	background-image: url(images/classic-spiral2.jpg);
	background-repeat: repeat;
}
</style>
<script type="text/javascript" src="scripts/jquery-prettyPhoto.js"></script>	</head>
<body id="top">
<div id="header"><span class="style20"></span>
  <div class="wrapper">
    <div class="fl_right"><img src="infoimages/default.png" width="70" height="70" /></div>
    <div class="fl_left">
      <h1> MI I'AANATUL IKHWAN</h1>
      <p>Jl. Masjid Al-Ikhwan Kp. Parung Serab Rt 05/03 No.12 Kel. Tirtajaya Kec. Sukmajaya Kota Depok 16412 Telp. (021) 77820520 </p>
    </div>
    <br class="clear" />
  </div>
</div>
<!-- ####################################################################################################### -->
<div id="topbar">
  <div class="wrapper">
    <div id="topnav">
      <ul>
        <li><a href="index.php">beranda</a></li>	<!--  class="active" -->
<?php 
if($_SESSION["ULOGIN"]){
	echo"
        <li><a href='?mnu=listinfo'>informasi</a></li>
        <li><a href='?mnu=listkegiatan'>kegiatan</a></li>
		<li><a href='?mnu=listnews'>berita</a></li>
        <li><a href='?mnu=listprofile'>tentang</a></li>
      </ul>
    </div>
	";
}
else{?>
        <li><a href="?mnu=fregistrasinew">pendaftaran</a></li>
        <li><a href="?mnu=listinfo">informasi</a></li>
        <li><a href="?mnu=listkegiatan">kegiatan</a></li>
		<li><a href="?mnu=listnews">berita</a></li>
        <li><a href="?mnu=listprofile">tentang</a></li>
		<li ><a href="?mnu=konfirmasi">konfirmasi Pembayaran</a></li>
      </ul>
    </div>
<?php }?>  
    <br class="clear" />
  </div>
</div>
<!-- ####################################################################################################### -->
<div id="breadcrumb">
  <div class="wrapper">
    <ul>
      <marquee style="color: #413D3D;">  
		<em>Selamat Datang <?php echo $_SESSION["CNAMA"] ;?>, di Website Penerimaan Siswa Baru <b>MI I'AANATUL IKHWAN Depok</b></em>
    </marquee></ul>
  </div>
</div>
<!-- ####################################################################################################### -->
<div id="container">
  <div class="wrapper">
    <div id="content">
	
	<!-- LOAD DATA-DATA CALON SISWA NYA -->
<?php	//	
	$kode=$_SESSION["KODELOG"];
	$sql="select * from  tbl_calonsiswa, tbl_psbsetup where f_nopendaftaran='$kode' ";
	$hasil=mysqli_query($sql);
	$data=mysqli_fetch_array($hasil);
		$namalengkap=$data["f_namalengkap"];
		$tempatlhrsiswa = $data["f_tempatlhrsiswa"];
		$tanggallhrsiswa=$data["f_tanggallhrsiswa"];
		$kelaminid=$data["f_kelamin"];
		$agamaid = $data["f_agama"];
		$kewarganegid = $data["f_kewarganeg"];
		$statusdiriid = $data["f_statusdiri"];
		$anakke = $data["f_anakke"];
		$saudarakandung = $data["f_saudarakandung"];
		$alamatsiswa = $data["f_alamatsiswa"];
		$notelpon = $data["f_notelpon"];
		$statusdaftar=$data["f_statusdaftar"];
		$kelas=$data["f_kelas"];
		$thnmasuk=$data["f_thnmasuk"];
	//	$password=$data["f_passwrod"];
	
		//DATA ORANG TUA KANDUNG DAN WALI CALON SISWA
		$namaayah = $data["f_namaayah"];
		$tempatlhrayah = $data["f_tempatlhrayah"];
		$tanggallhrayah=$data["f_tanggallhrayah"];
		$agamaidayah = $data["f_agamaidayah"];
		$kewarganegidayah = $data["f_kewarganegidayah"];
		$alamatayah=$data["f_alamatayah"];
		$kotaayah=$data["f_kotaayah"];
		$kecamatanayah = $data["f_kecamatanayah"];
		$kelurahanayah = $data["f_kelurahanayah"];
		$kodeposayah = $data["f_kodeposayah"];
		$notelponayah = $data["f_notelponayah"];
		$pendidikanidayah = $data["f_pendidikanidayah"];
		$pekerjaanidayah = $data["f_pekerjaanidayah"];
		$penghasilanidayah = $data["f_penghasilanidayah"];
		
		$namaibu = $data["f_namaibu"];
		$tempatlhribu = $data["f_tempatlhribu"];
		$tanggallhribu=$data["f_tanggallhribu"];
		$agamaidibu = $data["f_agamaidibu"];
		$kewarganegidibu = $data["f_kewarganegidibu"];
		$alamatibu=$data["f_alamatibu"];
		$kotaibu=$data["f_kotaibu"];
		$kecamatanibu = $data["f_kecamatanibu"];
		$kelurahanibu = $data["f_kelurahanibu"];
		$kodeposibu = $data["f_kodeposibu"];
		$notelponibu = $data["f_notelponibu"];
		$pendidikanidibu = $data["f_pendidikanidibu"];
		$pekerjaanidibu = $data["f_pekerjaanidibu"];
		$penghasilanidibu = $data["f_penghasilanidibu"];
		
		$namawali = $data["f_namawali"];
		$tempatlhrwali = $data["f_tempatlhrwali"];
		$tanggallhrwali=$data["f_tanggallhrwali"];
		$agamaidwali = $data["f_agamaidwali"];
		$kewarganegidwali = $data["f_kewarganegidwali"];
		$alamatwali=$data["f_alamatwali"];
		$kotawali=$data["f_kotawali"];
		$kecamatanwali = $data["f_kecamatanwali"];
		$kelurahanwali = $data["f_kelurahanwali"];
		$kodeposwali = $data["f_kodeposwali"];
		$notelponwali = $data["f_notelponwali"];
		$pendidikanidwali = $data["f_pendidikanidwali"];
		$pekerjaanidwali = $data["f_pekerjaanidwali"];
		$penghasilanidwali = $data["f_penghasilanidwali"];
		
		//DATA SEKOLAH ASAL
		$tahunlulus = $data["f_tahunlulus"];
		$lulusansekolah = $data["f_lulusansekolah"];
		$alamatsekolah=$data["f_alamatsekolah"];
		$nosttb = $data["f_nosttb"];
		//UNTUK YANG PENTING YE
		$telppsb = $data["f_telppsb"];
?>

	<!-- MENU CONTENT NYA -->
<?php 
	$mnu=$_GET["mnu"]; 
	if($mnu=="forangtuaedit"){include"system/calonsiswa/forangtuaedit.php";}
	else if($mnu=="fasalsekolahedit"){include"system/calonsiswa/fasalsekolahedit.php";}
	else if($mnu=="fcalonsiswaedit"){include "system/calonsiswa/fcalonsiswaedit.php";}
	else if($mnu=="flampiran"){include"system/calonsiswa/flampiran.php";}
	else if($mnu=="fuploadfoto"){include "system/calonsiswa/fuploadfoto.php";}
	else if($mnu=="fuploadakte"){include "system/calonsiswa/fuploadakte.php";}
	else if($mnu=="fuploadsktb"){include "system/calonsiswa/fuploadsktb.php";}
	else if($mnu=="formulir"){include "system/calonsiswa/formulir.php";}
	else if($mnu=="fformulir"){include "system/calonsiswa/fformulir.php";}
	// CONTENT WEBSITE
	else if($mnu=="fregistrasinew"){include"system/contentweb/fregistrasinew.php";}
	else if($mnu=="finformasidetail"){include"system/contentweb/finformasidetail.php";}
	else if($mnu=="listkegiatan"){include"system/contentweb/listkegiatan.php";}
	else if($mnu=="listnews"){include"system/contentweb/listnews.php";}
	else if($mnu=="listinfo"){include"system/contentweb/listinfo.php";}
	else if($mnu=="listprofile"){include"system/contentweb/listprofile.php";}
	else if($mnu=="konfirmasi"){include"system/contentweb/konfirmasi.php";}
	else if($mnu=="rincian"){include"system/contentweb/rincian.php";}
	else if($mnu=="brosur"){include"system/contentweb/brosur.php";}
else{?>

	<?php	#load nomor telpon sistem
		$dt=mysqli_query("select * from tbl_psbsetup ");
		while($d= mysqlI_fetch_array($dt)){
			$telppsb=$d["f_telppsb"];
		}	
	?>

<h2>MI I'AANATUL IKHWAN</h2>
<p class="Default"><strong>1. &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Visi Sekolah</strong>&nbsp;</p>
<p class="Default">Membentuk peserta didik yang menguasai IPTEK, berwawasan IMTAQ dengan tidak mengesampingkan kebutuhan Sumber Daya Manusia di lingkungan Masyarakat. </p>
<p class="Default"><strong>2. &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Misi Sekolah</strong>&nbsp;</p>
<p class="Default">MI I'aanatul Ikhwan memiliki misi  sebagai berikut:</p>
<ol start="1" type="1" class="style191">
  <li>Kokoh dan tangguh menjalankan syariat islam </li>
  <li>Bersaing dan unggul meraih prestasi </li>
  <li>Berbudi pekerti dan berakhlak mulia </li>
  <li>Berguna dan dibutuhkan kiprahnya didalam masyarakat</li>
  <li>Menjadi generasi yang sehat jasmani dan rohani, tidak terkontaminasi  narkoba</li>
  <li>Peduli terhadap lingkungan dan mandiri<br />
    <!-- petunjuk pengaksesan informasi -->
  </li>
  </ol>
<p>&nbsp;</p>
<h2>CARA PENDAFTARAN ONLINE</h2>

1. Calon Siswa Di Wajibkan Mempunyai Email Sebelum Daftar<br /><br />

2. Calon Siswa mengisi form pendaftaran di situs resmi MI Iaanatul Ikhwan <br /><br />

3. Calon Siswa wajib mengisi seluruh kolom isian dengan lengkap dan akurat, komputer 
&nbsp;&nbsp;&nbsp;&nbsp;tidak bisa menyimpan data yang tidak lengkap.<br /><br />

4. Lakukan pembayaran biaya pendaftaran sejumlah yang diberitahukan di Rincian Biaya 
&nbsp;&nbsp;&nbsp;&nbsp;melalui transfer Bank Ke Rekening BCA Atas Nama MI Iaanatul Ikhwan atau dengan 
&nbsp;&nbsp;&nbsp;&nbsp;langsung ke bagian Panitia Penerimaan Siswa Baru MI Iaanatul Ikhwan<br /><br />

5. Lakukan konfirmasi pembayaran, setelah semua kolom isian konfirmasi pembayaran
&nbsp;&nbsp;&nbsp;&nbsp;dilengkapi sistem akan memberikan nomor pendaftaran anda secara otomatis, berikut  
&nbsp;&nbsp;&nbsp;&nbsp;dengan password untuk login kedalam situs calon siswa, melalui email.<br /><br />

6. Silahkan anda login untuk isi data diri, upload lampiran dan mencetak bukti pendaftaran
&nbsp;&nbsp;&nbsp;&nbsp;online.<br /><br />

7. Setelah Bukti pendaftaran Online, Bukti Konfirmasi pembayaran dan struk pembayaran 
&nbsp;&nbsp;&nbsp;&nbsp;sudah diterima, anda diwajibkan untuk datang ke MI Iaanatul Ikhwan untuk   
&nbsp;&nbsp;&nbsp;&nbsp;mengembalikan formulir beserta dengan syarat pendaftaran yang lain.<br /><br />


   jika ingin di tanyakan silahkan hubungi panitia Psb
<div id='comments'>
        <ul class='commentlist'>
          <li class='comment_odd'>
            <div class='author'></div>
		  </li>
    </ul>
	  </div>

<?php } ?>
	
	
    </div>
    <div id="column">
      <div class="subnav">
<?php 
	if($_SESSION["ULOGIN"]){
		echo "
			<h2>Calon Siswa</h2>
<table width='200' border='0'>
  <tr>
    <td width='17%' valign='top'>No</td>
    <td width='4%' valign='top'>:</td>
    <td width='79%' valign='top'><b>".$_SESSION['ULOGIN']."</b></td>
  </tr>
  <tr>
    <td valign='top'>Nama</td>
    <td valign='top'>:</td>
    <td valign='top'>".$_SESSION['CNAMA']."</td>
  </tr>
</table>
<brr>
        <h2>Menu Calon Siswa</h2>
        <ul>
          <li><a href='?mnu=fcalonsiswaedit'>Data Calon Siswa</a></li>
          <li><a href='?mnu=forangtuaedit'>Orangtua dan Wali</a>
          <li><a href='?mnu=fasalsekolahedit'>Asal Sekolah</a></li>
          <li><a href='?mnu=flampiran'>Lampiran Calon Siswa</a></li>
          <li><a href='?mnu=fformulir'>Cetak Formulir</a></li>
		  <li><a href='?mnu=keluar'><b><span class='stylelogout'>keluar</span></b></a></li>
        </ul>
		<br>
		<h2>Menu Utama</h2>
        <ul>	
		";
	}
	else{?>
<h2>Masuk Calon Siswa</h2>	  
	  <form action="" method="post">
<table width="200" bordercolor="#FFCC33">
  <tr>
    <td width="47%"><div align="right">No.Pendaftaran: </div></td>
    <td width="53%">
      <input name="txtuser" type="text" size="13" />    </td>
  </tr>
  <tr>
    <td><div align="right">katasandi:</div></td>
    <td>
      <input name="txtpass" type="password" size="13" />    </td>
  </tr>
  <tr>
    <td>
      <div align="right">
        <input type="submit" name="Login" value="masuk" />
        </div></td>
    <td>
      </td>
  </tr>
</table>
</form>
		<br />
        <h2>Menu Utama</h2>
        <ul>			
          <li><a href='?mnu=fregistrasinew'><b>pendaftaran siswa</b></a></li>
<?php }?>
          <li><a href="?mnu=listinfo">informasi penerimaan siswa</a></li>
          <li><a href="?mnu=listkegiatan">kegiatan sekolah</a>
          <li><a href="?mnu=listnews">berita terbaru </a></li>
          <li><a href="?mnu=listprofile">tentang sekolah</a></li>
		  <li><a href="?mnu=rincian" class="style20">Rincian Biaya & Persyaratan</a></li>
		</span>
		<h2 align="center" class="style21"><a href="?mnu=brosur">Brosur Sekolah</a></h2>
		   <li>Contak Panitia Psb: 021- 92253479 </li>
		<center>
		  <img src="images/kontak.jpg" width="243" height="150" />
		</center>
		<!-- pingbox ym --><br />
       </div>
    </div>
    <br class="clear" />
  </div>
</div>
<!-- ####################################################################################################### -->
<!--foter-->
<!-- ####################################################################################################### -->
<div id="copyright">
  <div class="wrapper">
    
    <p class="fl_right">
		<?php if($_SESSION["CLEVEL"]=="admin" || $_SESSION["CLEVEL"]=="user"){?> 
		<a href="?mnu=keluar" title="keluar"><?php echo $_SESSION["CNAMA"] ; ?></a>
		<?php }	
		else{echo "masuk <a href='login.php' title='Masuk Administrator'>administrator</a>";}
		?>		
	</p>
    <br class="clear" />
  </div>
</div>
</body>
</html>


<!-- LOGIN SYSTEM -->

<?php	//LOGIN SYSTEM
	if(isset($_POST["Login"])){
	 
		$username=$_POST["txtuser"];
		$password=$_POST["txtpass"];  //mun pake encrypt standart php 	$password=md5($_POST[txtpass]);
		$sql="select * from tbl_calonsiswa where f_nopendaftaran='$username' and f_password='$password' and f_stscetak=0 ";
		$hasil=mysql_query($sql);
		$ada=mysql_num_rows($hasil);
		$data=mysql_fetch_array($hasil);
		$username=$data["f_nopendaftaran"];
		$ckode=$data["f_nopendaftaran"];
		$nm=$data["f_namalengkap"];
		$status=$d["f_statusterima"];
		if($ada >0){
			$_SESSION["KODELOG"]=$ckode;
			$_SESSION["CNAMA"]=$nm;
			$_SESSION["CLEVEL"]=$status;
			$_SESSION["ULOGIN"]=$username;

			echo "<script>alert('$nm, LOGIN ANDA SUKSES');document.location.href='index.php';</script>";
		}
		else{
		
			session_destroy(); 
			echo "<script>alert('MAAF, NO.PENDAFTARAN DAN PASSWORD HARUS BENAR');document.location.href='index.php';</script>";
		}
	}

	//	WAKTU TANGGAL BULAN & TAHUN
	function WKT($sekarang){
		$tanggal = substr($sekarang,8,2)+0;
		$bulan = substr($sekarang,5,2);
		$tahun = substr($sekarang,0,4);
	
		$judul_bln=array(1=> "Januari", "Februari", "Maret", "April", "Mei","Juni", "Juli", "Agustus", "September","Oktober", "Nopember", "Desember");
		$wk=$tanggal." ".$judul_bln[(int)$bulan]." ".$tahun;
		return $wk;
	}

	//	LOGOUT DARI SYSTEM
	if($mnu=="keluar"){
		session_destroy();
		echo "<script>alert('TERIMAKASIH ATAS PARTISIPASINYA');document.location.href='index.php';</script>";
	}
?>

