<?php

	mysql_connect("localhost","root","");
	mysql_select_db("db_psbnew");	
	$kode=$_GET['kode'];
	
	$data = mysql_fetch_array(mysql_query("select * from  tbl_calonsiswa where f_nopendaftaran='$kode'"));

		$nopendaftaran=$data["f_nopendaftaran"];
		$namalengkap=$data["f_namalengkap"];
		$tempatlhrsiswa=$data["f_tempatlhrsiswa"];
		$tanggallhrsiswa=$data["f_tanggallhrsiswa"];
		$kelaminid=$data["f_kelamin"];
		$agamaid=$data["f_agama"];
		$anakke=$data["f_anakke"];
		$saudarakandung=$data["f_saudarakandung"];
		$alamatsiswa=$data["f_alamatsiswa"];
		$notelpon=$data["f_notelpon"];
		$statusdaftar=$data["f_statusdaftar"];
		$kelas=$data["f_kelas"];
		$thnmasuk=$data["f_thnmasuk"];
		
		//DATA ORANG TUA KANDUNG DAN WALI CALON SISWA
		$namaayah=$data["f_namaayah"];
		$alamatayah=$data["f_alamatayah"];
		$kotaayah=$data["f_kotaayah"];
		$kecamatanayah=$data["f_kecamatanayah"];
		$kelurahanayah=$data["f_kelurahanayah"];
		$kodeposayah=$data["f_kodeposayah"];
		$notelponayah=$data["f_notelponayah"];
		$pekerjaanidayah=$data["f_pekerjaanidayah"];
		$penghasilanidayah=$data["f_penghasilanidayah"];
		$namaibu=$data["f_namaibu"];
		$alamatibu=$data["f_alamatibu"];
		$kotaibu=$data["f_kotaibu"];
		$kecamatanibu=$data["f_kecamatanibu"];
		$kelurahanibu=$data["f_kelurahanibu"];
		$kodeposibu=$data["f_kodeposibu"];
		$notelponibu=$data["f_notelponibu"];
		$pekerjaanidibu=$data["f_pekerjaanidibu"];
		$penghasilanidibu=$data["f_penghasilanidibu"];
		$namawali=$data["f_namawali"];
		$alamatwali=$data["f_alamatwali"];
		$kotawali=$data["f_kotawali"];
		$kecamatanwali=$data["f_kecamatanwali"];
		$kelurahanwali=$data["f_kelurahanwali"];
		$kodeposwali=$data["f_kodeposwali"];
		$notelponwali=$data["f_notelponwali"];
		$pekerjaanidwali=$data["f_pekerjaanidwali"];
		$penghasilanidwali=$data["f_penghasilanidwali"];

		//DATA SEKOLAH ASAL
		$tahunlulus=$data["f_tahunlulus"];
		$lulusansekolah=$data["f_lulusansekolah"];
		$nosttb=$data["f_nosttb"];
		$alamatsekolah=$data["f_alamatsekolah"];
		$asalsekolah=$data["f_asalsekolah"];
		$alasanpindah=$data["f_alasanpindah"];		
		//FOTO CALON SISWA
		$foto=$data["f_foto"];
		

require('fpdf.php');
class PDF extends FPDF{
	function Header(){
		$this->Image('Logo MI Iaanatul Ikhwan.jpg',5,4,-500);
		$this->SetFont('Arial','B',10);
		$this->text(43,8,'YAYASAN PENDIDIKAN ISLAM I�AANATUL IKHWAN (YPII) KAMPUNG SERAB');
		$this->setFont('Arial','',15);
		$this->text(50,13,'MADRASAH IBTIDAIYAH I�AANATUL IKHWAN');
		$this->setFont('Arial','',18);
		$this->text(60,20,'STATUS : TERAKREDITASI.B');
		$this->setFont('Arial','',9);
		$this->text(32,25,'Alamat : Jl.Masjid Al-Ikhwan No.12 Kp.Serab Kel.Tirtajaya Kec.Sukmajaya Kota Depok Telp.021.77820520');
		$this->text(5,28,'============================================================================================================');
	}
	function Footer(){
		#Position at 1.5 cm from bottom
		$q=mysql_query('select * from tbl_psbsetup ');
		$d=mysql_fetch_array($q);
		$this->SetY(-15);
		$this->SetFont('Arial','I',8);
		$this->Cell(0,10,'Panitia Penerimaan Siswa/siswi Baru MI Iaanatul Ikhwan Depok',0,0,'C');
	}
}

$tgl = date('d/M/Y');
$pdf = new PDF();
$pdf->Open();
$pdf->addPage();
$pdf->setAutoPageBreak(false);
$pdf->setFont('Arial','',14);
$pdf->text(35,33,'FORMULIR PENDAFTARAN ONLINE SISWA BARU TAHUN '.$thnmasuk);
$pdf->setFont('arial','',10);

$pdf->text(10,50,'Nomor Pendaftaran');
$pdf->text(10,55,'Nama Lengkap');
$pdf->text(10,60,'Tempat, Tanggal Lahir');
$pdf->text(10,65,'Jenis Kelamin');
$pdf->text(10,70,'Agama');
$pdf->text(10,75,'Alamat');
$pdf->text(10,80,'Nomor Telepon');
$pdf->text(10,85,'Asal RA/TK dan No. SKTB');
$pdf->text(10,90,'Tahun Lulus');
$pdf->text(10,95,'Status Masuk');
$pdf->text(10,100,'Masuk Di Kelas');
$pdf->text(10,105,'Nama Ayah');
$pdf->text(10,110,'Nama Ibu');
$pdf->text(10,115,'Pekerjaan Orangtua');
$pdf->text(10,120,'Penghasilan Orangtua');
$pdf->text(10,125,'Saudara Kandung');
$pdf->text(10,130,'Nomor Telepon Ayah dan Ibu');
$pdf->text(10,135,'Alamat Orangtua');
$pdf->text(10,140,'Nama Wali');
$pdf->text(10,145,'Pekerjaan Wali');
$pdf->text(10,150,'Penghasilan Wali');
$pdf->text(10,155,'Nomor Telepon Wali');
$pdf->text(10,160,'Alamat Wali');
#from table in database
$pdf->text(60,50,': '.$nopendaftaran);
$pdf->text(60,55,': '.$namalengkap);
$pdf->text(60,60,': '.$tempatlhrsiswa.', '.$tanggallhrsiswa);
$pdf->text(60,65,': '.$kelaminid);
$pdf->text(60,70,': '.$agamaid);
$pdf->text(60,75,': '.$alamatsiswa);
$pdf->text(60,80,': '.$notelpon);

$pdf->text(60,85,': '.$lulusansekolah.''.$asalsekolah.' / '.$nosttb);
$pdf->text(60,90,': '.$tahunlulus);
$pdf->text(60,95,': '.$statusdaftar);
$pdf->text(60,100,': '.$kelas);

$pdf->text(60,105,': '.$namaayah);
$pdf->text(60,110,': '.$namaibu);
$pdf->text(60,115,': '.$pekerjaanidayah.' dan '.$pekerjaanidibu);
$pdf->text(60,120,': '.$penghasilanidayah.' dan '.$penghasilanidibu);
$pdf->text(60,125,': '.$saudarakandung.' orang');
$pdf->text(60,130,': '.$notelponayah.' / '.$notelponibu);
$pdf->text(60,135,': '.$alamatayah.', '.$kelurahanayah.', '.$kecamatanayah.', '.$kotaayah);
$pdf->text(60,140,': '.$namawali);
$pdf->text(60,145,': '.$pekerjaanidwali);
$pdf->text(60,150,': '.$penghasilanidwali);
$pdf->text(60,155,': '.$notelponwali);
$pdf->text(60,160,': '.$alamatwali.', '.$kelurahanwali.', '.$kecamatanwali.', '.$kotawali);
$pdf->text(10,175,'Dengan ini saya menyatakan bahwasannya data di atas adalah benar, dan apabila terjadi perbedaan dengan bukti asli','C');
$pdf->text(10,180,'maka saya siap menerima konsekuensi dari panitia tanpa sanggahan.');

#foto siswa
$pdf->Image($foto,160,45,30,31); //93,227,-500

//$ketua = $data[f_ketuapanitia];
$pdf->text(130,200,"JAKARTA , ".$tgl);
$pdf->text(130,225,$namalengkap);

#menutup session
//session_destroy();
$pdf->output();
?>