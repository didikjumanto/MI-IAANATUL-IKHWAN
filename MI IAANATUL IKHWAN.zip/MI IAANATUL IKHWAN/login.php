<?php 
session_start();
?><style type="text/css">
<!--
body {
	margin-top: 100px;
	background-color: ;
}
body,td,th {
	color: #CCCCCC;
}
.style9 {
	color: #333333;
	font-weight: bold;
}
-->
</style>

<div align="center"><img src="infoimages/default.jpg" width="180" height="180" />
  <form action="" method="post">
    
    <table width="299" align="center" bgcolor="#FFFFFF">
            <tr>
              <td width="71" align="right"><span class="style9">pengguna :</span></td>
              <td width="189"><input name="txtuser" type="text" id="txtuser" size="25" /></td>
            </tr>
            <tr>
               <td align="right"><span class="style9">katasandi :</span></td>
               <td><input name="txtpass" type="password" id="txtpass" size="25" /></td>
            </tr>
            <tr>
               <td height="26"></td>
               <td valign="top"><input name="Login" type="submit" id="Login" value="Masuk" />
               <a href="index.php"><input name="reset" type="reset" value="Batal" /></a></td>
            </tr>
            <tr>
              <td height="26" colspan="2"><div align="center" class="style9">Masuk Administrator</div></td>
            </tr>
</table>

</form>
</div>


<?php	//	LOGIN SYSTEM
	require "koneksi.php";	
	if(isset($_POST["Login"])){
		$username=$_POST["txtuser"];
		$password=md5($_POST[txtpass]);
		$sql="select * from `tbl_user` where f_username='$username' and f_password='$password'";
		$hasil=mysqli_query($sql);
		$ada=mysqli_num_rows($hasil);
		$data=mysqli_fetch_array($hasil);
		$username=$data["f_username"];
		$ckode=$data["f_kodeuser"];
		$nm=$data["f_namalengkap"];
		$tingkat=$data["f_hakakses"];
		if($ada >0){
			$_SESSION["1KODELOG"]=$ckode;
			$_SESSION["1CNAMA"]=$nm;
			$_SESSION["1CLEVEL"]=$tingkat;
			$_SESSION["1ULOGIN"]=$username;
	
			echo "<script>alert('$nm, LOGIN BERHASIL');document.location.href='administrator.php';</script>";
		}
		else{
			session_destroy();
			echo "<script>alert('MAAF, USERNAME DAN PASSWORD HARUS BENAR');document.location.href='login.php';</script>";
		}
	
	}

?>